# DISCO MUSIC
Discover New Music

# In Production - v0.0.5
Currently Using:
ReactJS
Webpack
Babel
Firebase

import React from "react";
import PropTypes from 'prop-types';


export class Rightbar extends React.Component {
    render() {
        return (
            <div className="rightbar">

            <h2>Nothing Here right Now</h2>

             </div>
        );
    }
}
